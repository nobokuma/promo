
new YTComments({

  /* This refers to the element which the youtube comments will be inserted in. */
  el: document.querySelector("#yt-comments"),

  /* This refers to the comment data. */
  comments: [
    {
      img: "https://yt3.ggpht.com/ytc/AAUvwnjF74vH7EMiv2CT3s8LUz80hujPthpGw0D-5sizAg=s176-c-k-c0x00ffffff-no-rj",
      username: "PewDiePie",
      date: "5 hours ago",
      text: "Are you subscribed to me?",
      likesAmt: "5.6 K"
    },
    {
      img: "https://yt3.ggpht.com/a/AATXAJy2mIL918ACigh6wKXv_uUD5f06MGdmkksG1Ece=s48-c-k-c0xffffffff-no-rj-mo",
      username: "10,000 Subs with 2 Videos!",
      date: "4 hours ago",
      text: "Best guy in world 😎",
      likesAmt: "1.2 K"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJy8Y5gVF9w4E-hqK7oTDfk4oFQDsOTEqcOgtNNXMg=s48-c-k-c0xffffffff-no-rj-mo",
      username: "Lya DeppSoul",
      date: "4 hours ago",
      text: "Love you!!! ❤️❤️",
      likesAmt: "935"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJwEBrunjatnllegmq3Uz-EK-jm7y3ZovjB-=s48-c-k-c0xffffffff-no-rj-mo",
      username: "Der Mikkel",
      date: "3 hours ago",
      text: "Can my brother also claim? 😒",
      likesAmt: "877"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJyreGgCwKqias_V4OK5Uy8sXPdYiRF17xUZht_n=s48-c-k-c0xffffffff-no-rj-mo",
      username: "Freddy W.",
      date: "2 hours ago",
      text: "finally Thanks to This Amazing Guy",
      likesAmt: "655"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJzwTT9XHcWvMDbR6Slq40X2Gl374oHjN4SRFGt_=s48-c-k-c0xffffffff-no-rj-mo",
      username: "Ali vom Laden",
      date: "1 day ago",
      text: "buying car 💸💸💰💰",
      likesAmt: "521"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJxjnSnobr4U-XrU1-R0Q1vaTo5h6I12vmPBWHC7pw=s48-c-k-c0xffffffff-no-rj-mo",
      username: "Lee",
      date: "1 day ago",
      text: "love you my brother 😍˜",
      likesAmt: "451"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJziDmtBdq1k7bWh5SddND25ETiz-3dLlRFVnEVf=s48-c-k-c0xffffffff-no-rj-mo",
      username: "ani ma",
      date: "1 day ago",
      text: "like to win $10k",
      likesAmt: "428"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJzzR_ZUpRMD407jWTtOnSG1LZYopUgRQ0y84tE7=s48-c-k-c0xffffffff-no-rj-mo",
      username: "MC Ente",
      date: "1 day ago",
      text: "favourite youtuber always been :)",
      likesAmt: "355"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJw4AzqMKJND9QexPElZpdvKcc4wPnM3WgtRzvgK3w=s48-c-k-c0xffffffff-no-rj-mo",
      username: "Nick",
      date: "1 day ago",
      text: "so fucking easy hahaha!! big <3",
      likesAmt: "255"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJyBg_M6c235cSfuRaVMNlwaNBi61AiCVE1aog=s48-c-k-c0xffffffff-no-rj-mo",
      username: "Stefan Utthoff",
      date: "1 day ago",
      text: "So what to buy? or keep 😂",
      likesAmt: "224"
    },
      {
      img: "https://yt3.ggpht.com/a/AATXAJzqvOt4kGm6vGhhfq-Iee5g5zr6ISAnLHqm1WgWhg=s48-c-k-c0xffffffff-no-rj-mo",
      username: "Spitzkopf",
      date: "1 day ag",
      text: "FOOR MY BIRTHDAY!!! THANKS",
      likesAmt: "193"
    },
  ]

});
